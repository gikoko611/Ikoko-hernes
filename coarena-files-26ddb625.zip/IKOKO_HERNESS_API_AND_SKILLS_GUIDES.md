# IKOKO HERNESS — API Setup & Skills Setup Guide

## PART A — AI provider / API setup

IKOKO HERNESS talks to **any OpenAI-compatible HTTP API**. No provider and **no model ID is hardcoded**.

### A1. Add a provider
`Settings → AI Providers → Add`

| Field | What to enter |
|---|---|
| name | your label (e.g. "OpenAI", "Groq", "Ollama LAN") |
| base URL | `https://api.openai.com/v1`, `https://api.groq.com/openai/v1`, `https://api.together.xyz/v1`, `http://192.168.1.10:11434/v1` (Ollama), `http://127.0.0.1:8000/v1` (LM Studio) … |
| API key | provider token (may be empty for keyless local servers) |
| model | picked from the auto-loaded list, or typed manually |

### A2. Load models (automatic discovery)
Press **Load models** → the app issues `GET {baseURL}/models`, parses `data[].id` and shows every
model the server returned. The chosen ID is stored per provider and becomes the active model.

### A3. Test the connection
Press **Test** → a live `GET {baseURL}/models` call. Success reports the model count and a sample;
failure shows the HTTP status plus the raw error body (handy for 401 / 404 / timeout cases).

### A4. Streaming chat
`AI Agent → Send` → `POST {baseURL}/chat/completions` with `"stream": true`.
Server-sent events are parsed incrementally, so tokens appear as they are produced.
**Stop** aborts the HTTP stream itself (connection closed, not only the UI).

### A5. Tool calling / autonomous execution
The agent always advertises its tool schemas (OpenAI `tools` / function format). On a `tool_calls`
reply IKOKO executes the tool locally, appends the real result as a `tool` message and continues the
conversation (autonomous loop, max 8 steps). Sensitive operations
(`delete_path`, `run_command`, `github_push_file`, `build_apk`, `video_*`, `mix_audio`,
`unzip_archive`) raise a system **approval dialog** first; denying returns "User denied the operation"
to the model so it can continue safely.

### A6. Credential security
API keys and GitHub tokens are encrypted with **AES-256-GCM** using a key generated inside the
**Android Keystore** (API 23+). Only ciphertext reaches SharedPreferences.
`Settings → Security → Rotate provider keys` re-encrypts every credential.

### A7. Troubleshooting
| Symptom | Cause / fix |
|---|---|
| `HTTP 401` | wrong key, or key not sent to a gateway that needs a different header |
| `HTTP 404` on /models | base URL must end in the API root (`.../v1`), not `/v1/models` |
| `HTTP 429` | provider rate limit — retry later |
| No tokens appear | server lacks SSE support — use a provider with `"stream": true` support |
| Empty model list | server has no `/models` endpoint — type the model ID manually |

---

## PART B — Skills setup

A **skill** is a capability the agent gains. Format: `SKILL.md` = YAML front-matter + instruction
body, optionally bundled with resources inside a `.zip` / `.skill` archive.

### B1. Authoring
```markdown
---
name: Blender Character Builder
category: 3d
version: 1.0.0
description: Generates Blender character rigs with neon-green and gold materials.
---

# Blender Character Builder
When the user asks for a character:
1. Call the `blender_script` tool with kind="character".
2. Report the generated .py path and remind the user that Blender runs on a desktop machine.
```
* `name` – title in the manager (falls back to the file name)
* `category` – grouping label (default `general`)
* `version` – free-form version string
* `description` – one-line summary, shown in the agent prompt
* body – instructions injected into the model context when the skill is **enabled**

### B2. Import
`Skills → Import .md/.zip/.skill` → pick the file via the system picker.
* `.md` / `.txt` → parsed directly.
* `.zip` / `.skill` → extracted by `core/ZipSafe.java`, which **rejects** absolute paths, `..`
  traversal entries, archives above 200 MB or 5 000 entries, and reports rejected entries.
  The `SKILL.md` found at any depth inside becomes the skill definition; the remaining files stay
  alongside it as resources.

### B3. Manage
* **Enable / Disable** – only enabled skills are injected into the agent system prompt.
* **Search** – matches name, category and description.
* **Export** – writes `name_vX.Y.Z.zip` containing a regenerated `SKILL.md`.
* **Delete** – removes the database row and the imported files from the workspace.

### B4. Bundled starter skills
`app/src/main/assets/skills/` ships `code_assistant.md`, `video_editing.md`, `3d_modeling.md`.
Import them once to see the skill pipeline working end-to-end.

### B5. Worked example – a custom skill
1. Write `my_skill.md` with the front-matter above.
2. `Skills → Import` → choose `my_skill.md` → it appears in the list, enabled, version 1.0.0.
3. Ask the agent a question in that domain — the skill body is now part of its system prompt.
4. `Export` to obtain `my_skill_v1.0.0.zip` for distribution; the recipient imports it and gets the
   same capability.
