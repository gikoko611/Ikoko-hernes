# IKOKO HERNESS — Feature Testing Report

Build under test: `app-release.apk`, package `com.ikoko.herness`, minSdk 21 / targetSdk 34,
JDK 17 + Gradle 8.7 + AGP 8.1.4 + Android SDK 34, 28 Java files / 3 794 LOC.

## 1. Build verification (actually executed)
| Check | Result |
|---|---|
| `gradle assembleRelease assembleDebug` | **BUILD SUCCESSFUL** — 65 actionable tasks, exit code 0 |
| Release APK | `app/build/outputs/apk/release/app-release.apk` — 253 226 bytes |
| Debug APK | `app/build/outputs/apk/debug/app-debug.apk` — 309 611 bytes |
| APK structure | 18 entries, `AndroidManifest.xml` present, single `classes.dex`, `META-INF/CERT.RSA` + `CERT.SF` (APK is signed → installable) |
| Native libraries | **none** (`lib/` empty) → no ARM64-only code, runs on armeabi-v7a |
| Assets in APK | `assets/studio/studio.html`, `assets/studio/three.min.js` (r150), `assets/skills/{code_assistant,video_editing,3d_modeling}.md` |
| Compile defects fixed during the build | 7 (missing `Context`/`File` imports, `System.timeMillis` typo, duplicate switch-scope variable `name`, subclassing the final `BufferInfo`, `long`/`float` conversion in the splash timer, `ViewParent`→`View` cast, definite-assignment of the studio `WebView`, checked `InterruptedException` in the approval latch) |

## 2. Automated logic tests (head-less JVM, real execution)
`core/SkillManager` + `core/ZipSafe` were compiled against `android.jar` and executed by
`tools/LogicTests.java`:

```
PASS front-matter name      PASS front-matter category   PASS front-matter version
PASS front-matter description PASS body kept              PASS fallback name
PASS fallback description    PASS benign extract count    PASS benign content
PASS traversal rejected     PASS traversal file not written PASS safe entry still extracted
RESULT pass=12 fail=0
```
| Test | Expectation | Result |
|---|---|---|
| Parse `SKILL.md` front-matter (name/category/version/description) | values extracted | PASS |
| Body preserved as instructions | body kept | PASS |
| Skill without front-matter | supplied fallback name used, description derived from body | PASS |
| Benign ZIP extraction | 2 entries written, content byte-identical | PASS |
| ZIP with `../../evil.txt` | entry rejected, **no file created outside destination** | PASS |
| ZIP with `/abs/path.txt` | entry rejected | PASS |
| Safe entry in malicious ZIP | still extracted (no over-blocking) | PASS |

## 3. Per-module status (only what was really executed is marked PASS)
| Module | Status |
|---|---|
| Build / packaging / signing / manifest | **PASS (executed)** |
| Skill parsing & ZIP path-traversal defence | **PASS (executed)** |
| Splash animation, chat UI, 3D studio, video studio, GitHub panel, terminal | Implemented and compiled; **not executed on a physical device here** (no emulator/ADB device in this environment) — listed as "device pass required" in the README matrix |
| Live AI provider streaming, model listing, connection test | Requires a real provider key — not available offline; verified by code path + build only |
| Blender | Script generation verified as text output; Blender itself is external and was not executed |
| GitHub push / Actions polling | Implemented against the documented REST endpoints; no live repository was pushed from this sandbox |

> **Honesty statement:** no device-level behaviour is claimed as "passed on device" because no device
> was available. Build-level and JVM-level results above are real, reproducible, and were executed.
> The repository ships the full GitHub Actions pipeline so the ARMv7 APK can be rebuilt and re-verified
> on any machine or on the Redmi 9A itself.

## 4. Reproduction
```bash
export JAVA_HOME=/path/to/jdk-17
export ANDROID_SDK_ROOT=/path/to/android-sdk
cd IKOKO && gradle assembleRelease --no-daemon
aapt dump badging app/build/outputs/apk/release/app-release.apk
# logic tests
javac -cp $ANDROID_SDK_ROOT/platforms/android-34/android.jar -d classes app/src/main/java/com/ikoko/herness/core/*.java tools/LogicTests.java
java -cp classes:$ANDROID_SDK_ROOT/platforms/android-34/android.jar LogicTests
```
