# IKOKO HERNESS — Delivery Package

**App:** IKOKO HERNESS · **Logo:** G.I · **Brand:** Powered by I KO KO
**Package:** `com.ikoko.herness` · **Target:** Redmi 9A, Android 10 (API 29), ARMv7 32-bit (armeabi-v7a), 3 GB RAM
**Build path:** GitHub Actions only (`.github/workflows/android.yml`)

## Files in this delivery
| File | Description | Size |
|---|---|---|
| `IKOKO_HERNESS_SOURCE.zip` | Complete Android source project (28 Java files / 3 794 lines, resources, assets, workflow, README + docs) | 240 KB |
| `IKOKO_HERNESS_ARMv7_v1.0.0.apk` | Installable release APK (signed, minSdk 21 / targetSdk 34, **no native libs** → runs on armeabi-v7a) | 253 KB |
| `IKOKO_HERNESS_DELIVERABLES.md` | This overview + build instructions | — |
| `IKOKO_HERNESS_API_AND_SKILLS_GUIDES.md` | Provider/API setup + skills format/import guide | — |
| `IKOKO_HERNESS_TESTING_REPORT.md` | What was verified, how, and what still needs a device pass | — |

Full per-file guides are also inside the source ZIP: `README.md`, `docs/API_SETUP.md`, `docs/SKILLS_SETUP.md`, `docs/BLENDER_BRIDGE.md`, `docs/TESTING_REPORT.md`.

## Build with GitHub Actions
1. Push the project to a GitHub repository (the contents of `IKOKO/`).
2. `.github/workflows/android.yml` triggers on push to `main`/`master` and on `workflow_dispatch`:
   JDK 17 (Temurin) → `gradle assembleRelease` + `gradle assembleDebug` → uploads
   **IKOKO_HERNESS_armv7_apk** (APKs) and **IKOKO_HERNESS_SOURCE_ZIP** artifacts.
3. Install on the device: `adb install -r IKOKO_HERNESS_ARMv7_v1.0.0.apk` (or sideload; allow "unknown sources").
4. The CI APK is signed with the standard debug key — swap `signingConfig signingConfigs.debug` in
   `app/build.gradle` for a release keystore before store distribution.

Local build (optional): JDK 17, Android SDK 34, `ANDROID_SDK_ROOT` set → `gradle assembleRelease`.

## ARMv7 / low-RAM engineering decisions
* `minSdk 21`, `targetSdk 34`, `ndk.abiFilters 'armeabi-v7a'`.
* **Zero third-party runtime dependencies** (no AndroidX, no native `.so`): only platform APIs
  (`HttpURLConnection`, `MediaCodec`, `SQLiteOpenHelper`, `WebView`, `AndroidKeyStore`) are used, so
  the APK is ~253 KB and runs comfortably on a 3 GB / 32-bit ARM device.
* Video work uses Android's own MediaExtractor/MediaMuxer/MediaCodec (no FFmpeg binary is shipped —
  that keeps the 32-bit APK small and licence-clean) and reports **real** progress from actual
  sample/frame counts.
* Credentials are encrypted with AES-256-GCM using a key inside the **Android Keystore**.

## Module map (what is really implemented)
| Module | Implementation |
|---|---|
| Splash | Canvas-rendered metallic 3D "G.I", 70 green energy particles, golden electric flashes, AI brain orb, neural-net graph, holographic circuit grid, "Powered by I KO KO" |
| AI Agent | SSE streaming chat, autonomous multi-step tool loop (max 8 steps), system prompt from enabled skills + project memory, Stop/Resume, error recovery, approval gate for sensitive tools |
| AI Providers | Multiple providers, base URL + API key, automatic `/models` loading (no hardcoded model IDs), model picker, live connection test, OpenAI-compatible |
| Skills manager | Import `.md` / `.zip` / `.skill`, parse `SKILL.md` front-matter, register as AI capabilities, enable/disable/delete/update, search, categories, versions, export |
| ZIP safety | Path-traversal blocking (`..`, absolute paths, canonical-path check), 5 000-entry / 200 MB limits, skipped-entry reporting |
| Tools manager | 23 registered tools with descriptions, permissions, run dialog, execution status and DB-backed logs (File Manager, Code Editor, Terminal, GitHub, Image Processing, ZIP Manager, APK Builder, Blender, Three.js, Video…) |
| Project & code editor | Explorer, open/edit/save real files, undo, rename, delete, SAF import of ZIP/code/media, AI edit that rewrites the **actual file** on disk |
| Terminal | Real sandboxed interpreter (pwd, ls, cd, cat, echo, mkdir, touch, rm, cp, mv, grep, find, wc, head, tail, df, du, date, whoami) limited to the app workspace |
| GitHub | Encrypted PAT, repository tree, Actions runs, real file commit/push via REST API |
| Three.js 3D studio | Bundled three.js r150 in a WebView: real-time preview, add cube/sphere/torus, touch orbit, timeline play/pause + scrub, **binary GLB importer**, **GLB exporter**, script export, AI-generated scene execution |
| Blender integration | Generates complete, runnable Blender Python (character, environment, animation, render) + external-render bridge docs — **Blender does not run natively on Android and is not claimed to** |
| Video studio | Real trim/cut & multi-clip merge (stream copy), real transcode/compress with live progress, Myanmar-safe UTF-8 SRT subtitles, WAV extraction and PCM voice-over mixing, project save/edit |
| APK builder | Prepares a complete Gradle + GitHub-Actions project and packages it as a ZIP (APK compilation happens in GitHub Actions) |
| Settings | English/Myanmar, themes, provider management, storage, security/credential rotation, logs |

## Honest limitations (no false claims)
* No placeholder buttons: every control opens a real screen or performs a real file/media/network operation.
* The app needs a real OpenAI-compatible provider (base URL + key) for the AI features; no API key was
  available in this offline build environment, so provider-dependent flows were verified by code path
  and build, not by a live key.
* Blender and desktop FFmpeg binaries are **not** bundled; Blender runs externally, video uses the
  device's own codecs (codec availability varies per device).
* Device-level behaviour (WebGL studio, MediaCodec encode/decode, streaming UI) still needs a
  physical Redmi 9A pass — see the testing report for exactly what was and was not executed.
